#include <stdio.h>
#include <stdlib.h>
#include <string.h>
// TDA DE LISTA DE PERSONAS 
/*------------- estructura de datos -------------*/
typedef struct nodoG
{
  char* rut;
  char* nombre;
  char* apellido;
  int edad;
  int dia;
  int mes;
  int year;
  int idVacuna;
  int dia2dosis;
  int mes2dosis;
  int year2dosis;
  struct nodoG* siguiente;
}nodoG;

typedef struct listaG
{
  nodoG* inicio;
}listaG;


/*------------- operaciones -------------*/

//crea una lista vacia de gente
listaG* crearlistaVaciaG()
{
  listaG* lista=(listaG*)malloc(sizeof(listaG));
  lista->inicio=NULL;
  return lista;
}
//revisa si una lista es vacia
int eslistaVaciaG(listaG* lista)
{
  if (lista->inicio == NULL)
    return 1;
  else
    return 0;
}
//calculo el largo de una llave
int largolistaG(listaG* lista){
	int contador=0;
	nodoG* actual=lista->inicio;
	if(eslistaVaciaG(lista)){
		return contador;
	}
	else if(actual->siguiente == NULL){
		return 1;
	}
	else{
		while(actual->siguiente != NULL ){
			actual=actual->siguiente;
			contador++;
		}
		return contador+1;
	}
}
//recorre una lista printeando los datos de cada nodo
void recorrerlistaG(listaG* lista)
{
  if (!eslistaVaciaG(lista))
  {
	printf("%d\n",largolistaG(lista));
    nodoG* a=lista->inicio;
    while (a!=NULL)
    {
      printf("%s %s %s %d %d/%d/%d %d \n",a->rut,a->nombre,a->apellido,a->edad,a->dia,a->mes,a->year,a->idVacuna);
      a=a->siguiente;
    }
    printf("\n");
  }
  else
    printf("lista vacia\n");
}
//recorre una lista printeando los datos de cada nodo
void recorrerlistaG2(listaG* lista)
{
  if (!eslistaVaciaG(lista))
  {
	printf("%d\n",largolistaG(lista));
    nodoG* a=lista->inicio;
    while (a!=NULL)
    {
      printf("%s %s %s %d %d/%d/%d %d/%d/%d %d \n",a->rut,a->nombre,a->apellido,a->edad,a->dia,a->mes,a->year,a->dia2dosis,a->mes2dosis,a->year2dosis,a->idVacuna);
      a=a->siguiente;
    }
    printf("\n");
  }
  else
    printf("lista vacia\n");
}
//inserta un nodo al inicio de una lista
void insertarInicioG(listaG* lista,char rut[15], char nombre[20], char apellido[20], int edad, int dia, int mes, int year,int idV)
{
  nodoG* nuevo=(nodoG*)malloc(sizeof(nodoG));
  nuevo->rut=rut;
  nuevo->nombre=nombre;
  nuevo->apellido=apellido;
  nuevo->edad=edad;
  nuevo->idVacuna=idV;
  nuevo->siguiente = lista->inicio;
  nuevo->dia= dia;
  nuevo->mes = mes;
  nuevo->year = year;
  lista->inicio=nuevo;
}
//inserta un nodo al final de una lista
void insertarnodoGFinalG(listaG* lista,char rut[10], char nombre[25], char apellido[25], int edad, int dia, int mes, int year,int idV){
	nodoG* nuevo=(nodoG*)malloc(sizeof(nodoG));
	nuevo->rut=rut;
	nuevo->nombre=nombre;
	nuevo->apellido=apellido;
	nuevo->edad=edad;
	nuevo->dia=dia;
  nuevo->mes=mes;
 	nuevo->year=year;
	nuevo->idVacuna=idV;
	nuevo->siguiente=NULL;
	if(eslistaVaciaG(lista)==1){//si esta vacia se inserta al inicio
		insertarInicioG(lista,rut,nombre,apellido,edad,dia,mes,year,idV);
	}
	else{
		nodoG* actual=lista->inicio;
		while(actual->siguiente != NULL ){
			actual=actual->siguiente;
		}
		actual->siguiente=nuevo;
	}
}
//libera una lista
void liberarlistaG(listaG* lista){
	if(!eslistaVaciaG(lista)){
		nodoG* auxiliar;
		auxiliar = lista->inicio;
		while(auxiliar!=NULL){
			lista->inicio = lista->inicio->siguiente;
			free(auxiliar);
			auxiliar = lista->inicio;
		}
	}
}
//elimina un nodo inicial
void eliminarInicio(listaG* lista)
{
  nodoG* auxiliar;
  if(!eslistaVaciaG(lista))
  {
    auxiliar=lista->inicio;
    lista->inicio=lista->inicio->siguiente;
    free(auxiliar);
  }
}
//elimina un nodo final
void eliminarFinal(listaG* lista){
	if(eslistaVaciaG(lista)==1){//si esta vacia no hago nada
	
	}
	else{
		nodoG* actual=lista->inicio;
		nodoG* anterior;
		while(actual->siguiente != NULL ){
			anterior=actual;
			actual=actual->siguiente;
		}
		//cuando el actual apunta a null entonces ese es el ultimo
		anterior->siguiente=NULL;
		//hago que anterior apunte a null y elimino el actual
		free(actual);
	}
}
//busca un nodo y lo retorna, en caso de no estar, retorna null
nodoG* buscarNodo(listaG* entrada,char rut[10]){
	nodoG* nodoActual;
	nodoActual =entrada->inicio;
	while(nodoActual!=NULL){
		if(strcmp(nodoActual->rut,rut)==0){
			return nodoActual;
		}
		nodoActual=nodoActual->siguiente;
	}
	return NULL;
}
//elimina un nodo
void eliminarNodo(listaG* lista, char rut[10]){
	nodoG* actual;
	nodoG* anterior;
	actual=lista->inicio;
	if(strcmp(actual->rut,rut)==0){
		eliminarInicio(lista);
	}else if(lista->inicio==NULL){

	}
	else{
		while((actual!=NULL)&&(strcmp(actual->rut,rut)!=0)){
			anterior=actual;
			actual=actual->siguiente;
		}
		if(strcmp(actual->rut,rut)==0){
			anterior->siguiente=actual->siguiente;
			free(actual);
		}
	}
}
//inserta un nodo despues de otro en especifico
void insertarDespues(listaG *lista, char rut[10],char nombre[25],char apellido[25],int edad, int dia,int mes,int year,int idVacuna,char apellidoBus[25]){
	//recorro la lista
	//encuentro al nodo de apellidoBus
	//nodonuevo->siguiente=nodobuscado->siguiente;
	//nodobuscado->siguiente=nodonuevo;
	nodoG* buscado;
	nodoG* nuevo;
	buscado=lista->inicio;
	while(buscado!=NULL){
		if(strcmp(buscado->apellido,apellidoBus)==0){
			nuevo->rut = rut;
			nuevo->nombre = nombre;   
			nuevo->apellido =apellido;
			nuevo->edad = edad;
			nuevo->dia = dia;
			nuevo->mes = mes;
			nuevo->year = year ;
			nuevo->idVacuna = idVacuna;
			nuevo->siguiente=buscado->siguiente;
			buscado->siguiente=nuevo;
		}
		buscado=buscado->siguiente;
	}
}
//inserta un nodo segun apellido
void insertarSort (listaG *lista, char rut[10],char nombre[25],char apellido[25],int edad, int dia,int mes,int year,int idVacuna){
    nodoG* nuevo = (nodoG*)malloc(sizeof(nodoG));
    nodoG* anterior = (nodoG*)malloc(sizeof(nodoG));
    nodoG* actual = (nodoG*)malloc(sizeof(nodoG));
    int cmp;
    anterior = NULL;
    actual = lista->inicio;
    while ( actual != NULL ) {
        cmp = strcmp(apellido, actual->apellido); 
        if (cmp < 0) {
          break;
        } else if (cmp==0) {
          insertarDespues(lista,rut,nombre,apellido,edad,dia,mes,year,idVacuna,actual->apellido);
          break;
        }
        anterior = actual;
        actual = actual->siguiente;
    }
    nuevo->rut = rut;
    nuevo->nombre = nombre;   
    nuevo->apellido =apellido;
    nuevo->edad = edad;
    nuevo->dia = dia;
    nuevo->mes = mes;
    nuevo->year = year ;
    nuevo->idVacuna = idVacuna;
    if ( anterior == NULL ) {
      nuevo->siguiente = lista->inicio;
      lista->inicio = nuevo;
    } else {
      anterior->siguiente = nuevo;
      nuevo->siguiente = actual;
    }
}
//funcion que lee un archivo creando una lista para personas
void leerGente(listaG* lista,char* doc){
  // 19200759-3 Mateo Gonzalo 24 05/04/21 3
  int cantidadG;
  int i;
  int edad;
  int vacunaID;
  int dia,mes,year;
  char slash[2] = "/";
  FILE * archivoG = fopen(doc, "r");
  fscanf(archivoG,"%d",&cantidadG);
  for(i=0;i<cantidadG;i++){
    char* rut=(char*)malloc(sizeof(char)*10);
    char* nombre=(char*)malloc(sizeof(char)*25);
    char* apellido=(char*)malloc(sizeof(char)*25);
    char* fecha=(char*)malloc(sizeof(char)*10);
 	  char* token;
    fscanf(archivoG,"%s %s %s %d %s %d\n",rut,nombre,apellido,&edad,fecha,&vacunaID);
	  token = strtok(fecha,slash);
  	dia= atoi(token);
  	token = strtok(NULL, slash);
  	mes = atoi(token);
  	token = strtok(NULL, slash);
	  year = atoi(token);
	  insertarSort(lista,rut,nombre,apellido,edad,dia,mes,year,vacunaID);
	}
  //cierro archivo
  fclose(archivoG);
}
//funcion que genera una lista de personas con su vacunacion completa
void vacunacionCompleta(listaG* entrada1,listaG* entrada2, listaG* salida){
  nodoG* gActual;
  nodoG* gDos;
  gDos=entrada2->inicio;
  while(gDos!=NULL){
    if((buscarNodo(salida,gDos->rut)==NULL)&&(buscarNodo(entrada1,gDos->rut)==NULL)){
      insertarnodoGFinalG(salida,gDos->rut,gDos->nombre,gDos->apellido,gDos->edad,gDos->dia,gDos->mes,gDos->year,gDos->idVacuna);
    }
    gDos=gDos->siguiente;
  }
  gActual=entrada1->inicio;
  while(gActual!=NULL){
    if(buscarNodo(entrada2,gActual->rut)!=NULL){
      nodoG* agregar;
      agregar=buscarNodo(entrada2,gActual->rut);
      insertarnodoGFinalG(salida,gActual->rut,gActual->nombre,gActual->apellido,gActual->edad,gActual->dia,gActual->mes,gActual->year,gActual->idVacuna);
      insertarnodoGFinalG(salida,agregar->rut,agregar->nombre,agregar->apellido,agregar->edad,agregar->dia,agregar->mes,agregar->year,agregar->idVacuna);
      gActual=gActual->siguiente;
    }else{
    gActual=gActual->siguiente;
    }
  }
  
}
//funcion que elimina gente de la lista v1d si esque aparecen en la lista v2d
void eliminarVacunados(listaG* v1d,listaG* v2d){
  //reviso si un nodo de v1d ya esta en v2d, en caso de estar ahi, lo elimino
  nodoG* nodoAct;
  nodoAct=v1d->inicio;
  while(nodoAct!=NULL){
    if(buscarNodo(v2d,nodoAct->rut)){
      eliminarNodo(v1d,nodoAct->rut);
    }
    nodoAct = nodoAct->siguiente;
  }
}
//no hice un fecha.h porque era innecesario
int bisiesto(int y){
  if(y%400 ==0){
    return 1;
  }
  else if((y%4 ==0) && (y%100!=0)){
    return 1;
  }
  else{
    return 0;
  }
}
int limiteMes(int mes,int year){
  if(mes==2){
    if(bisiesto(year)==1){
      return 29;//bisiesto
    }
    return 28;//no bisiesto
  }
  else if((mes==1)||(mes==3)||(mes==5)||(mes==7)||(mes==8)||(mes==10)||(mes==12)){
    return 31;//estos meses tienen 31 dias
  }
  else{
    return 30;//si no es ninguno de esos meses anteriores, retorno 30
  }
}
//inserta un nodo ordenado segun el int dia
void insertarSortDia(listaG *lista, char rut[10],char nombre[25],char apellido[25],int edad, int dia,int mes,int year,int dia2,int mes2,int year2,int idVacuna){	
    nodoG* nuevo = (nodoG*)malloc(sizeof(nodoG));
    nodoG* anterior = (nodoG*)malloc(sizeof(nodoG));
    nodoG* actual = (nodoG*)malloc(sizeof(nodoG));
    anterior = NULL;
    actual = lista->inicio;
    while ( actual != NULL ) {
        //aqui debo hacer los calculos de anterior->dia2 > actual->dia2
        if(dia2<actual->dia2dosis){
          break;
        }
        anterior = actual;
        actual = actual->siguiente;
    }
    nuevo->rut = rut;
    nuevo->nombre = nombre;   
    nuevo->apellido =apellido;
    nuevo->edad = edad;
    nuevo->dia = dia;
    nuevo->mes = mes;
    nuevo->year = year ;
	  nuevo->dia2dosis = dia2;
    nuevo->mes2dosis = mes2;
    nuevo->year2dosis = year2 ;
    nuevo->idVacuna = idVacuna;
    if ( anterior == NULL ) {
        nuevo->siguiente = lista->inicio;
        lista->inicio = nuevo;
    } else {
        anterior->siguiente = nuevo;
        nuevo->siguiente = actual;
    }
}
//funcion para ordenar una lista segun un int dia
void ordenarDia(listaG* entrada,listaG* salida){
	nodoG* actual;
	actual=entrada->inicio;
	while(actual!=NULL){	
		insertarSortDia(salida,actual->rut,actual->nombre,actual->apellido,actual->edad,actual->dia,actual->mes,actual->year,actual->dia2dosis,actual->mes2dosis,actual->year2dosis,actual->idVacuna);
		actual=actual->siguiente;
	}
}